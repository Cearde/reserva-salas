import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
interface IAuthContext {
    isAdmin: boolean;
    isAuthLoading: boolean;
    isUserValido: boolean;
}
/**
 * The provider component that wraps the app and provides the auth status.
 */
export declare const AuthProvider: React.FC<{
    children: React.ReactNode;
    context: WebPartContext;
}>;
/**
 * Custom hook to easily consume the AuthContext.
 */
export declare const useAuth: () => IAuthContext;
export {};
//# sourceMappingURL=AuthContext.d.ts.map