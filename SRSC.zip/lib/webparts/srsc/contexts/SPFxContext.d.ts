import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
declare const SPFxContext: React.Context<WebPartContext | undefined>;
/**
 * Custom hook to consume the SPFxContext.
 * It ensures the context is not undefined when used.
 */
export declare const useSPFxContext: () => WebPartContext;
export default SPFxContext;
//# sourceMappingURL=SPFxContext.d.ts.map