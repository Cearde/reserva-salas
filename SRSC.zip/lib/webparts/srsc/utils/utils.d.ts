export declare const getRestrictedDates: (rangeDays?: number) => Date[];
export declare const legendItems: {
    label: string;
    color: string;
}[];
export declare const getStatusColor: (disponibilidad: string) => string;
export declare const calcularPermisos: (isAdmin: boolean) => "Acceso Total" | "Acceso Limitado";
export declare const onFormatDate: (date?: Date) => string;
export declare const APP_VERSION = "2.7.0.3";
//# sourceMappingURL=utils.d.ts.map