import { WebPartContext } from "@microsoft/sp-webpart-base";
import { IDropdownOption } from "@fluentui/react";
import "@pnp/sp/site-users/web";
import { IPisoItem, IReservationSPItem, IHotspot, IHorarioItem, IExistingReservation, IAvailableRoom, IReservationReportItem, IVicepresidenciaItem, IPlanificacionHoraItem, ISPSalaItem, IDivisionItem, IGerenciaItem, IUsuarioItem, IUploadResult, IHorarioSala, ISala } from '../components/models/entities';
export declare class SPService {
    private context;
    constructor(context: WebPartContext);
    /**
     * Fetches items from a SharePoint list where the 'activo' field is true.
     * @param listName The name of the SharePoint list.
     * @returns A promise that resolves to an array of IDropdownOption.
     */
    fetchActiveListItems(listName: string, additionalSelects?: string[], filters?: string): Promise<IDropdownOption[]>;
    /**
     * Gets all the necessary dropdown options for the reservation form.
     * @returns A promise that resolves to an object containing arrays of options for plantas, pisos, and usuarios.
     */
    getFormDropdownOptions(): Promise<{
        plantas: IDropdownOption[];
        pisos: IDropdownOption[];
        usuarios: IDropdownOption[];
    }>;
    getPisosWithPlantaId(): Promise<IDropdownOption[]>;
    /**
     * Fetches the clickable hotspots for a given floor.
     * @param floorId The ID of the floor.
     * @returns A promise that resolves to an array of hotspot items.
     */
    getHotspotsForFloor(floorId: number): Promise<IHotspot[]>;
    /**
     * Fetches room data for a given floor and maps it to the ISala interface.
     * @param pisoId The ID of the floor.
     * @returns A promise that resolves to an array of ISala objects.
     */
    getSalasByPiso(pisoId: number, fecha: Date, plantaId: number): Promise<ISala[]>;
    getDisponibilidadSalas(pisoId: number, fecha: Date, plantaId: number): Promise<ISala[]>;
    /**
     * Fetches available hours from 'LM_Horario' list, filtered by PISO, PLANTA, and Day of Week.
     * @param pisoId The ID of the selected floor (PISO).
     * @param plantaId The ID of the selected building (PLANTA).
     * @param dayOfWeek The day of the week (e.g., "Lunes", "Martes").
     * @returns A promise that resolves to an array of IHorarioItem.
     */
    getHorarios(pisoId: number, plantaId: number, dayOfWeek: string): Promise<IHorarioItem[]>;
    ensureUserInGroup(groupName: string, userEmail: string): Promise<any>;
    removeUserFromGroup(groupName: string, userId: number): Promise<boolean>;
    addUserInGroup(groupName: string, userEmail: string): Promise<any>;
    /**
     * Checks if the current user is a member of the specified SharePoint group.
     * @param groupName The name of the SharePoint group.
     * @returns A promise that resolves to true if the user is in the group, false otherwise.
     */
    isCurrentUserInGroup(groupName: string): Promise<boolean>;
    getReservasParaSala(salaId: number, fecha: Date): Promise<IExistingReservation[]>;
    /**
     * Creates a new reservation item by constructing the item and calling addReserva.
     * This method contains the business logic for creating a reservation.
     * @param params The raw data needed to create the reservation.
     */
    createReservation(params: {
        pisoId: number;
        salaId: number;
        usuarioId: number;
        selectedDate: Date;
        selectedHorarios: IHorarioSala[];
        attendees: {
            id?: string;
        }[];
    }): Promise<IReservationSPItem>;
    blockRoom(reservationData: IReservationSPItem): Promise<IReservationSPItem>;
    /**
     * Creates a new reservation item in the 'LO_PUESTORESERVADO' list.
     * @param reservationData The data for the new reservation.
     */
    private addReserva;
    getAvailableRoomsByPiso(pisoId: number, pisoName: string, plantaId: number, date: Date): Promise<IAvailableRoom[]>;
    getScheduleForSala(sala: ISala, pisoId: number, plantaId: number, date: Date): Promise<IHorarioSala[]>;
    getReportData(filters: {
        startDate?: Date;
        endDate?: Date;
        pisoId?: number;
    }): Promise<IReservationReportItem[]>;
    getSalas(pisoId?: number, includeInactive?: boolean): Promise<ISPSalaItem[]>;
    createSala(sala: ISPSalaItem): Promise<ISPSalaItem>;
    updateSala(sala: ISPSalaItem): Promise<ISPSalaItem>;
    deleteSala(id: number): Promise<void>;
    /**
     * Fetches all items from the LM_PISOS list, expanding the PLANTA lookup field.
     * @param includeInactive Optional: Whether to include inactive pisos. Defaults to false.
     * @returns A promise that resolves to an array of IPisoItem.
     */
    getPisos(includeInactive?: boolean): Promise<IPisoItem[]>;
    /**
     * Creates a new item in the LM_PISOS list.
     * @param piso The IPisoItem object to create.
     * @returns A promise that resolves to the created IPisoItem.
     */
    createPiso(piso: IPisoItem): Promise<IPisoItem>;
    /**
     * Updates an existing item in the LM_PISOS list.
     * @param piso The IPisoItem object to update.
     * @returns A promise that resolves to the updated IPisoItem.
     */
    updatePiso(piso: IPisoItem): Promise<IPisoItem>;
    /**
     * Deletes an item from the LM_PISOS list.
     * @param id The ID of the piso to delete.
     * @returns A promise that resolves when the item is deleted.
     */
    deletePiso(id: number): Promise<void>;
    /**
     * Fetches all items from the LM_PlanificacionHoras list.
     * @returns A promise that resolves to an array of IDropdownOption.
     */
    getPlanificacionHoras(): Promise<IDropdownOption[]>;
    /**
     * Creates a new item in the LM_Horario list.
     * @param pisoId The ID of the associated Piso.
     * @param plantaId The ID of the associated Planta.
     * @param horaTitle The title of the hour (e.g., "09:00 - 10:00").
     * @returns A promise that resolves to the created item.
     */
    createHorario(pisoId: number, plantaId: number, horaTitle: string): Promise<any>;
    /**
     * Fetches all LM_Horario items associated with a specific Piso.
     * @param pisoId The ID of the Piso.
     * @returns A promise that resolves to an array of LM_Horario items.
     */
    getHorariosForPiso(pisoId?: number, plantaId?: number): Promise<IHorarioItem | undefined>;
    /**
     * Creates or updates an LM_Horario item for a given Piso and Planta.
     * @param pisoId The ID of the associated Piso.
     * @param plantaId The ID of the associated Planta.
     * @param selectedHoraIds An array of IDs from LM_PlanificacionHoras.
     * @returns A promise that resolves to the created or updated item.
     *  const dayOfWeek = [ 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
     */
    createOrUpdateHorarioEntry(pisoId: number, plantaId: number, selectedHoraIds: number[]): Promise<void>;
    private saveSingleDay;
    uploadFileWithMetadata(listName: string, docId: number, metadata: any): Promise<void>;
    /**
     * Fetches the request digest for SharePoint API calls.
     * @returns A promise that resolves to the X-RequestDigest value.
     */
    private getRequestDigest;
    /**
     * Uploads a file to a SharePoint document library.
     * @param fileName The name of the file to upload.
     * @param fileContent The content of the file as an ArrayBuffer.
     * @param folderPath The server-relative URL of the folder to upload to (e.g., 'Shared Documents/Images').
     * @returns A promise that resolves to the server-relative URL of the uploaded file.
     */
    uploadFile(fileName: string, fileContent: ArrayBuffer, folderPath: string): Promise<IUploadResult>;
    /**
   * Asegura que toda la estructura de carpetas exista.
   * @param libraryName Nombre de la biblioteca (ej: 'LO_QRPUESTOS')
   * @param folderPath Ruta de subcarpetas (ej: 'Casa Matriz/piso 2')
   * @returns La URL relativa final de la carpeta
   */
    ensureFolderPath(folderPath: string): Promise<string>;
    getQR(salaID?: number, pisoId?: number): Promise<string>;
    getVicepresidencias(includeInactive?: boolean): Promise<IVicepresidenciaItem[]>;
    createVicepresidencia(vicepresidencia: IVicepresidenciaItem): Promise<IVicepresidenciaItem>;
    updateVicepresidencia(vicepresidencia: IVicepresidenciaItem): Promise<IVicepresidenciaItem>;
    deleteVicepresidencia(id: number): Promise<void>;
    getGerencias(includeInactive?: boolean): Promise<IGerenciaItem[]>;
    createGerencia(gerencia: IGerenciaItem): Promise<IGerenciaItem>;
    updateGerencia(gerencia: IGerenciaItem): Promise<IGerenciaItem>;
    deleteGerencia(id: number): Promise<void>;
    getUsuarios(includeInactive?: boolean): Promise<IUsuarioItem[]>;
    createUsuario(usuario: IUsuarioItem): Promise<IUsuarioItem>;
    updateUsuario(usuario: IUsuarioItem): Promise<IUsuarioItem>;
    deleteUsuario(id: number): Promise<void>;
    getDivisiones(includeInactive?: boolean): Promise<IDivisionItem[]>;
    createDivision(division: IDivisionItem): Promise<IDivisionItem>;
    updateDivision(division: IDivisionItem): Promise<IDivisionItem>;
    deleteDivision(id: number): Promise<void>;
    getEntityByFilter(listName?: string, filtro?: string): Promise<boolean>;
    getPlanificacionHorasItems(): Promise<IPlanificacionHoraItem[]>;
    createPlanificacionHora(hora: IPlanificacionHoraItem): Promise<IPlanificacionHoraItem>;
    updatePlanificacionHora(hora: IPlanificacionHoraItem): Promise<IPlanificacionHoraItem>;
    deletePlanificacionHora(id: number): Promise<void>;
}
//# sourceMappingURL=sp.d.ts.map