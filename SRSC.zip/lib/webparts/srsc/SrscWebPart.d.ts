import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface ISrscWebPartProps {
    description: string;
}
export default class SrscWebPart extends BaseClientSideWebPart<ISrscWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    private _usuarioIDLista;
    private _usuarioIDDivision;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
    private hideSharePointChrome;
}
//# sourceMappingURL=SrscWebPart.d.ts.map