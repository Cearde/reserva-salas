import { SPService } from '../services/sp';
import { IDropdownOption } from '@fluentui/react';
import { ISala } from '../components/models/entities';
import { MessageBarType } from '@fluentui/react';
interface DropdownOptions {
    plantas: IDropdownOption[];
    pisos: IDropdownOption[];
    usuarios: IDropdownOption[];
}
interface HookState<T> {
    data: T;
    loading: boolean;
    error?: {
        message: string;
        type: MessageBarType;
    };
}
export declare function useFormDropdownOptions(spService: SPService): HookState<DropdownOptions>;
export declare function useSalasByPiso(spService: SPService, selectedPiso?: number, fecha?: Date, plantaId?: number): HookState<ISala[]>;
export {};
//# sourceMappingURL=useReservaSalaData.d.ts.map