export interface ISPItem {
    Id: number;
    Title: string;
}
export interface ISPListItem {
    Id: number;
    Title: string;
    activo: boolean;
    IMAGEN?: string;
}
export interface ISPPisoItem {
    Id: number;
    Title: string;
    activo: boolean;
    IMAGEN?: string;
    PLANTA?: {
        Id: number;
        Title: string;
    };
}
export interface IPisoItem {
    Id?: number;
    Title: string;
    activo: boolean;
    IMAGEN?: string;
    idImgPiso?: number;
    PlantaId?: number;
    PlantaTitle?: string;
    Horarios?: {
        Id: number;
        Title: string;
    }[];
}
export interface ISPUser {
    Id: number;
    Title: string;
    Email: string;
}
export interface IReservationSPItem {
    PISOId: number;
    puestoid: number;
    PUESTOId: number;
    USUARIOId: number;
    FECHAINICIORESERVA: string;
    FECHATERMINORESERVA: string;
    ESTADO: string;
    HORARESERVADA?: string;
    FECHACOMIENZORESERVA?: string;
    FECHALIMITECHECK?: string;
    ASISTENTESId?: number[];
    COMENTARIOBLOQUEO?: string;
    USUARIORESERVAId: number;
    USUARIORESERVA?: ISPUser;
}
export interface IReservationData {
    pisoId: number;
    usuarioId: number;
    fechaReserva: Date;
}
export interface IHotspot {
    Id: number;
    Title: string;
    COORDENADA: string;
    PISOId: number;
    CAPACIDAD: number;
}
export interface IHorarioItem {
    Id: number;
    Title: string;
    HORAS: {
        ID: number;
        Title: string;
    }[];
    PISOId: number;
    PlantaId: number;
}
export interface IExistingReservation {
    HORARESERVADA: string;
    USUARIO: {
        Title: string;
        Id: number;
    };
}
export interface IAvailableRoom {
    pisoName: string;
    salaName: string;
    CAPACIDAD: number;
    availableHours: string;
    salaId: number;
    pisoId: number;
}
export interface IReportItem {
    Id: number;
    Planta: string;
    Piso: string;
    IMAGEN: string;
    COORDENADA: string;
    Sala: string;
    Usuario: string;
    FechaReserva: string;
    FechaTerminoReserva: string;
    BloqueHorario: string;
    Estado: string;
    FechaCheckIn: string;
    FechaCheckOut: string;
    KPI: string;
    Ver: string;
}
export interface IReservationReportItem {
    Id: number;
    FECHAINICIORESERVA: string;
    FECHATERMINORESERVA: string;
    PISO: {
        Title: string;
        ID: number;
        IMAGEN: string;
    };
    ESTADO: string;
    HORARESERVADA: string;
    FECHASALIDA: string;
    FECHAENTRADA: string;
    PUESTO: {
        Title: string;
        ID: number;
        COORDENADA: string;
    };
    USUARIO: {
        Title: string;
        ID: number;
    };
}
export interface ISPSalaItem {
    Id?: number;
    Title: string;
    COORDENADA: string;
    PLANTA?: {
        Id: number;
        Title: string;
    };
    PISO?: {
        Id: number;
        Title: string;
    };
    CAPACIDAD?: number;
    activo: boolean;
}
export interface ISalaItem {
    Id?: number;
    Title: string;
    COORDENADA: string;
    PLANTAId?: number;
    PLANTATitle?: string;
    PISOId?: number;
    PISOTitle?: string;
    CAPACIDAD?: number;
    activo: boolean;
}
export interface IVicepresidenciaItem {
    Id?: number;
    Title: string;
    activo: boolean;
}
export interface IPlanificacionHoraItem {
    Id?: number;
    Title: string;
}
export interface IDivisionItem {
    Id?: number;
    Title: string;
    activo: boolean;
}
export interface IGerenciaItem {
    Id?: number;
    Title: string;
    activo: boolean;
    VicepresidenciaId: number;
    VicepresidenciaTitle: string;
}
export interface ISPGerenciaItem {
    Id: number;
    Title: string;
    activo: boolean;
    VICEPRESIDENCIA: {
        Id: number;
        Title: string;
    };
}
export interface IHorarioSala {
    ID: string;
    IDSala: number;
    HORA: string;
    Disponibilidad: boolean;
    ReservadoPara?: string;
    statusText: string;
    reservadoPorText: string;
    statusColor: 'green' | 'red' | 'black';
}
export interface IReservaSalaScheduleProps {
    isOpen: boolean;
    pisoId: number;
    selectedPisoName: string;
    roomName: string;
    selectedDate: Date | undefined;
    usuarioId: number;
    horarios: IHorarioSala[];
    onClose: () => void;
    onSelectSlot: (horarios: IHorarioSala[], attendees: any[]) => void;
    isLoading?: boolean;
    CAPACIDAD: number;
}
export interface ISala {
    ID: number;
    Nombre: string;
    PisoID: number;
    PosicionX: number;
    PosicionY: number;
    CAPACIDAD: number;
    Disponibilidad: string;
}
export interface IUploadResult {
    Id: number;
    Url: string;
}
export interface ISPUsuarioItem {
    Id: number;
    activo: boolean;
    USUARIO: {
        Id: number;
        Name: string;
        Title: string;
        EMail: string;
    };
    division: {
        Id: number;
        Title: string;
    };
    GERENCIA: {
        Id: number;
        Title: string;
    };
    esAdmin: boolean;
}
export interface IUsuarioItem {
    Id?: number;
    usuarioId: number;
    LoginName: string;
    text: string;
    email: string;
    GerenciaId: number;
    GerenciaTitle?: string;
    activo: boolean;
    esAdmin: boolean;
    divisionId?: number;
    divisionTitle?: string;
}
export interface Iperson {
    id: number;
    text: string;
    secondaryText: string;
    loginName: string;
    imageUrl?: string;
    imageInitials: string;
}
//# sourceMappingURL=entities.d.ts.map