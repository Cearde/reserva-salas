import * as React from 'react';
import { ISrscProps } from './ISrscProps';
declare const Srsc: React.FC<ISrscProps>;
export default Srsc;
//# sourceMappingURL=Srsc.d.ts.map