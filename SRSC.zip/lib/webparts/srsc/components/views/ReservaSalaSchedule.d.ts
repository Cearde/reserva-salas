import * as React from 'react';
import { IReservaSalaScheduleProps } from '../models/entities';
declare const ReservaSalaSchedule: React.FC<IReservaSalaScheduleProps>;
export default ReservaSalaSchedule;
//# sourceMappingURL=ReservaSalaSchedule.d.ts.map