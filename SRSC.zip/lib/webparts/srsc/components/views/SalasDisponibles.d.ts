import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const SalasDisponibles: React.FC<IViewProps>;
export default SalasDisponibles;
//# sourceMappingURL=SalasDisponibles.d.ts.map