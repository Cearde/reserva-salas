import * as React from 'react';
declare const GenerarQR: React.FC;
export default GenerarQR;
//# sourceMappingURL=GenerarQR.d.ts.map