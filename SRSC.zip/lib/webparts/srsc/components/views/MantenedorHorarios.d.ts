import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const MantenedorHorarios: React.FC<IViewProps>;
export default MantenedorHorarios;
//# sourceMappingURL=MantenedorHorarios.d.ts.map