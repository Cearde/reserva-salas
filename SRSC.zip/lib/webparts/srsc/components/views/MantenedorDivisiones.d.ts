import * as React from 'react';
declare const MantenedorDivisiones: React.FC;
export default MantenedorDivisiones;
//# sourceMappingURL=MantenedorDivisiones.d.ts.map