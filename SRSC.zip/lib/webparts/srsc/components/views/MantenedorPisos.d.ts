import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const MantenedorPisos: React.FC<IViewProps>;
export default MantenedorPisos;
//# sourceMappingURL=MantenedorPisos.d.ts.map