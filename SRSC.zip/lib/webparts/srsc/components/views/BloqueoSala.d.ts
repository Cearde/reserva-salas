import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const BloqueoSala: React.FC<IViewProps>;
export default BloqueoSala;
//# sourceMappingURL=BloqueoSala.d.ts.map