import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const MantenedorSalas: React.FC<IViewProps>;
export default MantenedorSalas;
//# sourceMappingURL=MantenedorSalas.d.ts.map