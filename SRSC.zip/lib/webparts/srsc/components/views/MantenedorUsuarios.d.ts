import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const MantenedorUsuarios: React.FC<IViewProps>;
export default MantenedorUsuarios;
//# sourceMappingURL=MantenedorUsuarios.d.ts.map