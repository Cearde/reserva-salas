import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const MantenedorGerencia: React.FC<IViewProps>;
export default MantenedorGerencia;
//# sourceMappingURL=MantenedorGerencia.d.ts.map