import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const ReservaSala: React.FC<IViewProps>;
export default ReservaSala;
//# sourceMappingURL=ReservaSala.d.ts.map