import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const MisReservas: React.FC<IViewProps>;
export default MisReservas;
//# sourceMappingURL=MisReservar.d.ts.map