import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const MantenedorVicepresidencias: React.FC<IViewProps>;
export default MantenedorVicepresidencias;
//# sourceMappingURL=MantenedorVicepresidencias.d.ts.map