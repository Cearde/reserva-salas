import * as React from 'react';
import { IViewProps } from './IViewProps';
declare const Reportes: React.FC<IViewProps>;
export default Reportes;
//# sourceMappingURL=Reportes.d.ts.map