export interface IViewProps {
    usuarioIDLista: number;
    usuarioIDDivision: number;
}
//# sourceMappingURL=IViewProps.d.ts.map