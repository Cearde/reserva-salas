declare const styles: {
    overlay: string;
    dialog: string;
    roomName: string;
    list: string;
    item: string;
    disabled: string;
    reserved: string;
    closeBtn: string;
};
export default styles;
//# sourceMappingURL=ReservaSalaSchedule.module.scss.d.ts.map