/* tslint:disable */
require("./ReservaSalaSchedule.module.css");
const styles = {
  overlay: 'overlay_c0d97eb2',
  dialog: 'dialog_c0d97eb2',
  roomName: 'roomName_c0d97eb2',
  list: 'list_c0d97eb2',
  item: 'item_c0d97eb2',
  disabled: 'disabled_c0d97eb2',
  reserved: 'reserved_c0d97eb2',
  closeBtn: 'closeBtn_c0d97eb2'
};

export default styles;
/* tslint:enable */